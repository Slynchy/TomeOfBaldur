async function instantiate(module, imports = {}) {
  const adaptedImports = {
    env: Object.assign(Object.create(globalThis), imports.env || {}, {
      abort(message, fileName, lineNumber, columnNumber) {
        // ~lib/builtins/abort(~lib/string/String | null?, ~lib/string/String | null?, u32?, u32?) => void
        message = __liftString(message >>> 0);
        fileName = __liftString(fileName >>> 0);
        lineNumber = lineNumber >>> 0;
        columnNumber = columnNumber >>> 0;
        (() => {
          // @external.js
          throw Error(`${message} in ${fileName}:${lineNumber}:${columnNumber}`);
        })();
      },
      "console.error"(text) {
        // ~lib/bindings/dom/console.error(~lib/string/String) => void
        text = __liftString(text >>> 0);
        console.error(text);
      },
      "Date.now"() {
        // ~lib/bindings/dom/Date.now() => f64
        return Date.now();
      },
      seed() {
        // ~lib/builtins/seed() => f64
        return (() => {
          // @external.js
          return Date.now() * Math.random();
        })();
      },
    }),
  };
  const { exports } = await WebAssembly.instantiate(module, adaptedImports);
  const memory = exports.memory || imports.env.memory;
  const adaptedExports = Object.setPrototypeOf({
    acknowledgeExamination(_caseJson, _examId) {
      // assembly/index/acknowledgeExamination(~lib/string/String, ~lib/string/String) => ~lib/string/String | null
      _caseJson = __retain(__lowerString(_caseJson) || __notnull());
      _examId = __lowerString(_examId) || __notnull();
      try {
        return __liftString(exports.acknowledgeExamination(_caseJson, _examId) >>> 0);
      } finally {
        __release(_caseJson);
      }
    },
    makeDiagnosis(_caseJson, _diagId) {
      // assembly/index/makeDiagnosis(~lib/string/String, ~lib/string/String) => bool
      _caseJson = __retain(__lowerString(_caseJson) || __notnull());
      _diagId = __lowerString(_diagId) || __notnull();
      try {
        return exports.makeDiagnosis(_caseJson, _diagId) != 0;
      } finally {
        __release(_caseJson);
      }
    },
    acknowledgeTreatment(_caseJson, _treatmentId) {
      // assembly/index/acknowledgeTreatment(~lib/string/String, ~lib/string/String) => ~lib/string/String | null
      _caseJson = __retain(__lowerString(_caseJson) || __notnull());
      _treatmentId = __lowerString(_treatmentId) || __notnull();
      try {
        return __liftString(exports.acknowledgeTreatment(_caseJson, _treatmentId) >>> 0);
      } finally {
        __release(_caseJson);
      }
    },
    canPatientTalk(_caseJson) {
      // assembly/index/canPatientTalk(~lib/string/String) => bool
      _caseJson = __lowerString(_caseJson) || __notnull();
      return exports.canPatientTalk(_caseJson) != 0;
    },
    isSpeechRequired(_examId) {
      // assembly/index/isSpeechRequired(~lib/string/String) => bool
      _examId = __lowerString(_examId) || __notnull();
      return exports.isSpeechRequired(_examId) != 0;
    },
    addExamination(_caseJson, _examId) {
      // assembly/index/addExamination(~lib/string/String, ~lib/string/String) => ~lib/string/String | null
      _caseJson = __retain(__lowerString(_caseJson) || __notnull());
      _examId = __lowerString(_examId) || __notnull();
      try {
        return __liftString(exports.addExamination(_caseJson, _examId) >>> 0);
      } finally {
        __release(_caseJson);
      }
    },
    assessDifficulty(_caseJson) {
      // assembly/index/assessDifficulty(~lib/string/String) => f64
      _caseJson = __lowerString(_caseJson) || __notnull();
      return exports.assessDifficulty(_caseJson);
    },
    giveTreatment(_caseJson, _treatmentId) {
      // assembly/index/giveTreatment(~lib/string/String, ~lib/string/String) => ~lib/string/String | null
      _caseJson = __retain(__lowerString(_caseJson) || __notnull());
      _treatmentId = __lowerString(_treatmentId) || __notnull();
      try {
        return __liftString(exports.giveTreatment(_caseJson, _treatmentId) >>> 0);
      } finally {
        __release(_caseJson);
      }
    },
    generateCase(_settings) {
      // assembly/index/generateCase(assembly/HospitalCore/HospitalCore/ICaseGenerationSettings) => ~lib/string/String
      _settings = __lowerRecord43(_settings) || __notnull();
      return __liftString(exports.generateCase(_settings) >>> 0);
    },
    calculateRewardScore(_caseJson, _wasSuccess) {
      // assembly/index/calculateRewardScore(~lib/string/String, bool) => ~lib/string/String | null
      _caseJson = __lowerString(_caseJson) || __notnull();
      _wasSuccess = _wasSuccess ? 1 : 0;
      return __liftString(exports.calculateRewardScore(_caseJson, _wasSuccess) >>> 0);
    },
    isInitialized() {
      // assembly/index/isInitialized() => bool
      return exports.isInitialized() != 0;
    },
    getVersion() {
      // assembly/index/getVersion() => ~lib/string/String
      return __liftString(exports.getVersion() >>> 0);
    },
  }, exports);
  function __lowerRecord43(value) {
    // assembly/HospitalCore/HospitalCore/ICaseGenerationSettings
    // Hint: Opt-out from lowering as a record by providing an empty constructor
    if (value == null) return 0;
    const pointer = exports.__pin(exports.__new(0, 43));
    exports.__unpin(pointer);
    return pointer;
  }
  function __liftString(pointer) {
    if (!pointer) return null;
    const
      end = pointer + new Uint32Array(memory.buffer)[pointer - 4 >>> 2] >>> 1,
      memoryU16 = new Uint16Array(memory.buffer);
    let
      start = pointer >>> 1,
      string = "";
    while (end - start > 1024) string += String.fromCharCode(...memoryU16.subarray(start, start += 1024));
    return string + String.fromCharCode(...memoryU16.subarray(start, end));
  }
  function __lowerString(value) {
    if (value == null) return 0;
    const
      length = value.length,
      pointer = exports.__new(length << 1, 2) >>> 0,
      memoryU16 = new Uint16Array(memory.buffer);
    for (let i = 0; i < length; ++i) memoryU16[(pointer >>> 1) + i] = value.charCodeAt(i);
    return pointer;
  }
  const refcounts = new Map();
  function __retain(pointer) {
    if (pointer) {
      const refcount = refcounts.get(pointer);
      if (refcount) refcounts.set(pointer, refcount + 1);
      else refcounts.set(exports.__pin(pointer), 1);
    }
    return pointer;
  }
  function __release(pointer) {
    if (pointer) {
      const refcount = refcounts.get(pointer);
      if (refcount === 1) exports.__unpin(pointer), refcounts.delete(pointer);
      else if (refcount) refcounts.set(pointer, refcount - 1);
      else throw Error(`invalid refcount '${refcount}' for reference '${pointer}'`);
    }
  }
  function __notnull() {
    throw TypeError("value must not be null");
  }
  return adaptedExports;
}
export const {
  memory,
  getCurrentGameMode,
  setCurrentGameMode,
  acknowledgeExamination,
  makeDiagnosis,
  acknowledgeTreatment,
  canPatientTalk,
  isSpeechRequired,
  addExamination,
  assessDifficulty,
  giveTreatment,
  generateCase,
  calculateRewardScore,
  initialize,
  isInitialized,
  getVersion,
} = await (async url => instantiate(
  await (async () => {
    try { return await globalThis.WebAssembly.compileStreaming(globalThis.fetch(url)); }
    catch { return globalThis.WebAssembly.compile(await (await import("node:fs/promises")).readFile(url)); }
  })(), {
  }
))(new URL("debug.wasm", import.meta.url));
